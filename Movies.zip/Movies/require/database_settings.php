<?php
$host_name = "localhost";
$user_name = "root";
$password = "";
$database = "movie";
